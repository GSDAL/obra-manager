
import React, { useState } from 'react';
import Login from './Login';
import Partidas from '../components/Partidas';
import Avance from '../components/Avance';
import Stock from '../components/Stock';
import Alquileres from '../components/Alquileres';
import Personal from '../components/Personal';
import Programacion from '../components/Programacion';

const obras = ['Obra 1', 'Obra 2', 'Obra 3'];
const pestañas = ['Partidas', 'Avance', 'Stock', 'Alquileres', 'Personal', 'Programación'];

export default function App() {
  const [usuario, setUsuario] = useState(null);
  const [obraSeleccionada, setObraSeleccionada] = useState(null);
  const [pestana, setPestana] = useState('Partidas');

  const renderContenido = () => {
    switch (pestana) {
      case 'Partidas': return <Partidas />;
      case 'Avance': return <Avance />;
      case 'Stock': return <Stock />;
      case 'Alquileres': return <Alquileres />;
      case 'Personal': return <Personal />;
      case 'Programación': return <Programacion />;
      default: return <div>Selecciona una pestaña</div>;
    }
  };

  if (!usuario) return <Login onLogin={setUsuario} />;

  if (!obraSeleccionada)
    return (
      <div className="p-4">
        <h2 className="text-2xl mb-4">Selecciona una obra</h2>
        <ul className="space-y-2">
          {obras.map((obra) => (
            <li key={obra}>
              <button
                className="underline text-blue-600"
                onClick={() => setObraSeleccionada(obra)}
              >
                {obra}
              </button>
            </li>
          ))}
        </ul>
      </div>
    );

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Obra: {obraSeleccionada}</h2>
      <div className="flex space-x-2 mb-4">
        {pestañas.map((tab) => (
          <button
            key={tab}
            onClick={() => setPestana(tab)}
            className={`px-3 py-1 border rounded ${
              pestana === tab ? 'bg-blue-500 text-white' : 'bg-gray-100'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>
      <div className="border p-4">
        {renderContenido()}
      </div>
    </div>
  );
}
